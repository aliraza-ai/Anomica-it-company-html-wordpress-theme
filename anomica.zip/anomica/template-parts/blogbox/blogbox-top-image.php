<article class="themetechmount-box themetechmount-box-blog themetechmount-box-topimage themetechmount-blogbox-format-<?php echo get_post_format() ?> <?php echo themetechmount_sanitize_html_classes(themetechmount_post_class()); ?>">
	<div class="post-item">
		<div class="themetechmount-box-content">		
			<div class="tm-featured-outer-wrapper tm-post-featured-outer-wrapper">
				<?php echo themetechmount_get_featured_media( '', 'themetechmount-img-blog-top' ); // Featured content ?>
				<div class="tm-post-date"><span><?php echo get_the_date( 'd' ); ?></span><?php echo get_the_date( 'M' ); ?></div> 								<div class="tm-blog-overlay-iconbox">						    <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark" target="_blank"><i class="tm-anomica-icon-plus-1"></i></a>							</div>	
			</div>				            		
			<div class="themetechmount-box-desc">
				<div class="entry-header">
					<?php echo themetechmount_box_title(); ?>
					<?php echo anomica_entry_meta(); ?>
				</div>					
			</div>
        </div>
	</div>
</article>

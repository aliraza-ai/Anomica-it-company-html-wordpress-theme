<article class="themetechmount-box themetechmount-box-portfolio themetechmount-box-view-style-two themetechmount-portfolio-box-view-style-two <?php echo themetechmount_portfoliobox_class(); ?>">
	<div class="themetechmount-post-item">
			<?php echo themetechmount_featured_image('themetechmount-img-portfolio'); ?>
		<div class="themetechmount-box-content themetechmount-overlay">			
            <div class="themetechmount-box-content-inner">	
				<div class="themetechmount-icon-box themetechmount-media-link"><?php echo themetechmount_portfoliobox_media_link(); ?><a href=" <?php echo get_permalink(); ?>" class="themetechmount_pf_link"><i class="tm-anomica-icon-link"></i></a></div>			
			 </div>	
		</div>
		<div class="themetechmount-box-bottom-content">					
			<?php echo themetechmount_box_title(); ?>		
		</div>
	</div>
</article>
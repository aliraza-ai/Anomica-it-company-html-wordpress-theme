<article class="themetechmount-box themetechmount-box-portfolio themetechmount-box-view-style-one themetechmount-portfolio-box-view-style-one<?php echo themetechmount_portfoliobox_class(); ?>">
	<div class="themetechmount-post-item">	
		<div class="themetechmount-post-item-inner">
			<?php echo themetechmount_get_featured_media( get_the_ID(), 'themetechmount-img-blog-top', true ); ?>			
			<div class="themetechmount-box-bottom-content">		
				<div class="themetechmount-box-category"><?php echo themetechmount_portfolio_category(true); ?></div>
				<?php echo themetechmount_box_title(); ?>		
		    </div>
		</div>		
	</div>
</article>
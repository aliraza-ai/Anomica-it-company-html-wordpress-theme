<span class="themetechmount-box themetechmount-box-client themetechmount-box-view-separator-logo themetechmount-client-box-view-separator-logo">
	<?php echo themetechmount_wp_kses(themetechmount_featured_image()); ?>
</span>

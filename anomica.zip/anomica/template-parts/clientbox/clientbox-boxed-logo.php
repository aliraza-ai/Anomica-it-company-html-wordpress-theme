<span class="themetechmount-box themetechmount-box-client themetechmount-box-view-boxed-logo themetechmount-client-box-view-boxed-logo">
	<?php echo themetechmount_wp_kses(themetechmount_featured_image()); ?>
</span>

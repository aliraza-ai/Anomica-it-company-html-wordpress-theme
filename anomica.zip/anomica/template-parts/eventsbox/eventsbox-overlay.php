<article class="themetechmount-box themetechmount-box-events themetechmount-box-view-overlay themetechmount-events-box-view-overlay">
	<div class="themetechmount-post-item">
		<?php echo themetechmount_featured_image(); ?>
		<div class="themetechmount-box-content themetechmount-overlay">
            <div class="themetechmount-icon-box"><a href="<?php the_permalink(); ?>"><i class="tm-anomica-icon-link"></i></a></div>
            <div class="themetechmount-box-content-inner">
                <div class="themetechmount-box-title"><?php echo themetechmount_box_title(); ?></div>
                <div class="themetechmount-box-category"><?php echo themetechmount_events_category(true); ?></div>
            </div>
		</div>
	</div>
</article>
<header id="masthead" class="<?php echo themetechmount_header_style_class(); ?>">
	<div class="tm-header-block <?php echo themetechmount_headerclass(); ?>">
		<?php get_template_part('template-parts/header/header','floatingbar'); ?>
		<?php get_template_part('template-parts/header/header','topbar'); ?>
		<?php get_template_part('template-parts/header/header','main-infostack'); ?>
		<?php get_template_part('template-parts/header/header','titlebar'); ?>
		<?php get_template_part('template-parts/header/header','slider'); ?>
	</div>
</header><!-- .site-header -->
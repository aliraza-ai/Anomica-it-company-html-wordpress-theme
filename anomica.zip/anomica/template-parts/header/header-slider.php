<?php if( themetechmount_header_slider_show() ) : ?>
	<div class="themetechmount-slider-wrapper">
		<?php echo themetechmount_header_slider(); ?>
	</div>
<?php endif;  // themetechmount_titlebar_show() ?>








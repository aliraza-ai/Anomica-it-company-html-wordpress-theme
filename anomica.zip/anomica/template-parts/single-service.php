<?php
/*
 *
 *  Single Service - Top image
 *
 */

?>

<div class="tm-service-single-content-wrapper">
	<div class="themetechmount-common-box-shadow tm-service-single-content-wrapper-innerbox">		
		<div class="themetechmount-service-single-content-area">
			<?php echo themetechmount_service_description(); ?>
		</div><!-- .themetechmount-service-single-content-area -->
		
	</div>
	
</div>

<?php
global $anomica_theme_options;

$search_input = ( !empty($anomica_theme_options['search_input']) ) ? esc_attr($anomica_theme_options['search_input']) :  esc_attr_x("WRITE SEARCH WORD...", 'Search placeholder word', 'anomica');

$searchform_title = ( isset($anomica_theme_options['searchform_title']) ) ? esc_attr($anomica_theme_options['searchform_title']) :  esc_attr_x("Hi, How Can We Help You?", 'Search form title word', 'anomica');

if( !empty($searchform_title) ){
	$searchform_title = '<div class="tm-form-title">' . $searchform_title . '</div>';
}

if( !empty( $anomica_theme_options['header_search'] ) && $anomica_theme_options['header_search'] == true ){

?>

<div class="tm-search-overlay">
	<div class="tm-search-outer">
		<?php echo themetechmount_wp_kses($searchform_title); ?>
		<form method="get" class="tm-site-searchform" action="<?php echo esc_url( home_url() ); ?>">
			<input type="search" class="field searchform-s" name="s" placeholder="<?php echo esc_attr($search_input); ?>" />
			<button type="submit"><span class="tm-anomica-icon-search"></span></button>
		</form>
	</div>
</div>
<?php } ?>
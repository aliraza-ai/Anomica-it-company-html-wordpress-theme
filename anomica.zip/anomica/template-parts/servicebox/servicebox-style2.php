<article class="themetechmount-box themetechmount-box-service themetechmount-service-box-style2 <?php echo themetechmount_servicebox_class(); ?>">
	<div class="themetechmount-post-item">	
		<div class="tm-box-top-content">	
			<?php echo themetechmount_box_title(); ?>
			<div class="themetechmount-post-item-inner">
				<?php echo themetechmount_get_featured_media( get_the_ID(), 'medium_large', true ); ?>
			</div>
		</div>
		<div class="themetechmount-box-bottom-content">		
			<div class="themetechmount-box-desc">
				<div class="tm-short-desc">
					<?php the_excerpt(); ?>
				</div>
			</div> 
			<div class="themetechmount-serviceboxbox-readmore">
				<a href="<?php echo get_permalink(); ?>"><span class="tm-btn-icon-arrow"></span></a>
			</div>
		</div>
	</div>
</article>
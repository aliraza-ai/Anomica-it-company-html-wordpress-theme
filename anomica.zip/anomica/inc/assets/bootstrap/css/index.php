<?php
// Silence is golden.
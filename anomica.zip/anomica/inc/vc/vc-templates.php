<?php

/************************** Custom Template *****************************/
add_filter( 'vc_load_default_templates', 'themetechmount_custom_template_for_vc' );
if( !function_exists('themetechmount_custom_template_for_vc') ){
function themetechmount_custom_template_for_vc($maindata) {
	
	$maindata = array();
	
	/* ***************** */

	// Our Team
    $data               = array();
    $data['name']       = esc_attr__( 'Our Team', 'anomica' );
    $data['custom_class'] = 'anomica_our_team';
    $data['content']    = <<<TMCONTENTTILLTHIS
[vc_row tm_bgimagefixed="" tm_responsive_css="80476907|colbreak_no|||||||||colbreak_no|||||60px||30px||colbreak_no||||||||||colbreak_no|||||||||"][vc_column][tm-teambox h2="" show="6" column="three"][/tm-teambox][/vc_column][/vc_row]
TMCONTENTTILLTHIS;
	$maindata[] = $data;
	

	/************* END of Visual Composer Template list ***************/

	// Return all VC templates
	return $maindata;

}
}

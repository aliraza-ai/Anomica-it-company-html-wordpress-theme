<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// Customizer options - Coming soon with Anomica theme